import React, {Component} from "react";

export default class Edit extends Component{
    render(){
        return(
            <h1>Edit</h1>
        );
    }
}