import React, {Component} from "react";
import { Link } from "react-router-dom";
import NavDropdown from "react-bootstrap/NavDropdown";
import Container from 'react-bootstrap/Container';
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Image from "react-bootstrap/Image";
import "bootstrap/dist/css/bootstrap.min.css";
import "../css/style.css";

export default class Principal extends Component{
    render(){
        return(
            <Container>
                <Row>
                    <h1>La más likeadas</h1>
                </Row>
                {/* Contenedor para noticias más vistas*/}
                <Row>
                    <Col sm="12" md="8">
                        <Container>
                            <picture>
                                <Image fluid src="https://previews.123rf.com/images/aquir/aquir1311/aquir131100316/23569861-sample-grunge-red-round-stamp.jpg"/>
                                <Link to="/notice/id"><h1>Tutilo mas likeado</h1></Link>
                                <NavDropdown.Divider />
                            </picture>
                        </Container>
                    </Col>
                    <Col sm="12" md="4">
                        <Container>
                            <Link to="/notice/id">
                                <h5>Titulo</h5>
                                <p>fecha @ hora</p>
                                <NavDropdown.Divider />
                            </Link>
                        </Container>
                    </Col>
                </Row>
                {/* Contenedor de las siguientes mas vistas */}
                <Row>
                    <h1>Las siguientes...</h1>
                </Row>
                <Row>
                    <Col sm="12" md="4">
                        <Container>
                            <picture>
                                <Image fluid src="https://previews.123rf.com/images/aquir/aquir1311/aquir131100316/23569861-sample-grunge-red-round-stamp.jpg"/>
                                <Link to="/notice/id"><h4>Tutilo menos likeado</h4></Link>
                                <NavDropdown.Divider />
                            </picture>
                        </Container>
                    </Col>
                </Row>
            </Container>
        );
    }
}