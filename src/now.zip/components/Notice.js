import React, {Component} from "react";
import { Link } from "react-router-dom";
import NavDropdown from "react-bootstrap/NavDropdown";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from 'react-bootstrap/Container';
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Image from "react-bootstrap/Image";
import "bootstrap/dist/css/bootstrap.min.css";
import "../css/style.css";

import firebase from "./Firestore";
var db = firebase.firestore();

export default class Notice extends Component{
    constructor(props){
        super(props);
        this.state={
            text: "",
            image: "",
            title: "",
            idAuthor: "",
            date: "",
            time: "",
            likes: "",
            category: "",
            nameAut: "",
            surAut: ""
        }
        
        this.fill = this.fill.bind(this);
        this.likePlus = this.likePlus.bind(this);
    }
    
    fill(){
        var notiRef = db.collection('noticias').doc(this.props.match.params.id);
        notiRef.get().then(doc => {
            if(!doc.exists){
                console.log("No such Document!");
            } else {
                this.setState({
                    text: doc.data().texto,
                    image: doc.data().imagen,
                    title: doc.data().titulo,
                    idAuthor: doc.data().idAutor,
                    date: doc.data().fecha,
                    time: doc.data().hora,
                    likes: doc.data().likes,
                    category: doc.data().categoria,
                });
                
                db.collection('autores').doc(this.state.idAuthor).get().then(aut => {
                    if(!aut.exists){
                        console.log("no such Document!");
                    } else {
                        this.setState({
                            nameAut : aut.data().nombre,
                            surAut : aut.data().apellido,
                        });
                    }
                });
            }
        }).catch(err => {
            console.log("Error Gettin Document", err);
        });
        
    }
    
    likePlus(){
        var document = db.collection("noticias").doc(this.props.match.params.id);
        document.update({
            likes: this.state.likes + 1
        }).then(() => {
            this.setState({
                likes: this.state.likes+1
            });
        });
    }
    
    render(){
        this.fill();
        return(
            // Contenedor principal
            <Container>
                <Row>
                    <Col sm="0" md="2"></Col>
                    <Col sm="0" md="8">
                        <container>
                            <h1>{this.state.title}</h1>
                            <picture>
                                <Image fluid src={this.state.image}/>
                            </picture>
                            <p>por {this.state.nameAut} {" " + this.state.surAut} el {this.state.date} a las {this.state.time} hrs.</p>
                            <NavDropdown.Divider />
                            <Container>
                                <p>{this.state.text}</p>
                            </Container>
                            <Button variant="success" onClick={this.likePlus}>({this.state.likes}) like++</Button>
                        </container>
                    </Col>
                    <Col sm="0" md="2"></Col>
                </Row>
                {/* comentarios */}
                <Row>
                    <Col sm="0" md="2"></Col>
                    <Col sm="0" md="8">
                       <h3>Comentarios</h3>
                        <Form>
                            <Form.Label>Nombre</Form.Label>
                            <Form.Control type="text"/>
                            <Form.Label>Escribe tu comentario</Form.Label>
                            <Form.Control as="textarea" rows="3" />
                            <Button variant="primary">Comentar</Button>
                        </Form>
                    </Col>
                    <Col sm="0" md="2"></Col>
                </Row>
                {/* Contenedor para las siguientes mas vistas */}
                <Row>
                    <h3>Las más recientes...</h3>
                </Row>
                <Row>
                    <Col sm="12" md="4">
                        <Container>
                            <picture>
                                <Image fluid src="https://previews.123rf.com/images/aquir/aquir1311/aquir131100316/23569861-sample-grunge-red-round-stamp.jpg"/>
                                <Link to="/notice/id"><h4>Titulos recientes</h4></Link>
                                <NavDropdown.Divider />
                            </picture>
                        </Container>
                    </Col>
                </Row>
            </Container>
        );
    }
}